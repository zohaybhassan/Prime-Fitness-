-- Create the database
CREATE DATABASE gym;
USE gym;

-- Drop the receptionist table if it exists
DROP TABLE IF EXISTS receptionist;

-- Create the admin table
CREATE TABLE admin (
    fname VARCHAR(20) PRIMARY KEY,
    password VARCHAR(50)
);

-- Create the captain table
CREATE TABLE captain (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(20),
    address VARCHAR(20),
    phone VARCHAR(12),
    salary VARCHAR(20),
    passwords VARCHAR(20)
);

-- Create the receptionist table
CREATE TABLE receptionist (
    id VARCHAR(20) PRIMARY KEY,
    fname VARCHAR(20),
    lname VARCHAR(20),
    dob DATE NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(255) NOT NULL
);

-- Create the manager table
CREATE TABLE manager (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(20),
    address VARCHAR(20),
    phone VARCHAR(12),
    salary VARCHAR(20),
    password VARCHAR(20)
);

-- Create the suite table
CREATE TABLE suite (
    destination VARCHAR(20) PRIMARY KEY,
    price VARCHAR(10),
    capacity VARCHAR(5)
);

-- Create the passenger table
CREATE TABLE passenger (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(20),
    address VARCHAR(20),
    phone VARCHAR(12),
    destination VARCHAR(20),
    FOREIGN KEY (destination) REFERENCES suite(destination)
);

-- Create the locker table
CREATE TABLE locker (
    locker_id VARCHAR(20) PRIMARY KEY,
    location VARCHAR(50),
    size VARCHAR(10),
    assignedto VARCHAR(255),
    FOREIGN KEY (assignedto) REFERENCES passenger(id)
);

-- Create the machines table
CREATE TABLE machines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    buydate DATE NOT NULL,
    repairs VARCHAR(255) DEFAULT NULL
);

-- Create the trainer table
CREATE TABLE trainer (
    id VARCHAR(255) PRIMARY KEY,
    fname VARCHAR(255) NOT NULL,
    lname VARCHAR(255) NOT NULL,
    dob DATE NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(255) NOT NULL,
    comission DECIMAL(10, 2) NOT NULL
);

-- Create the dietplan table
CREATE TABLE dietplan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tid VARCHAR(255) NOT NULL,
    cid VARCHAR(255) NOT NULL,
    plan TEXT NOT NULL,
    FOREIGN KEY (tid) REFERENCES trainer(id),
    FOREIGN KEY (cid) REFERENCES passenger(id)
);

-- Create the workoutplan table
CREATE TABLE workoutplan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tid VARCHAR(255) NOT NULL,
    cid VARCHAR(255) NOT NULL,
    plan TEXT NOT NULL,
    FOREIGN KEY (tid) REFERENCES trainer(id),
    FOREIGN KEY (cid) REFERENCES passenger(id)
);

-- Create the complaints table
CREATE TABLE complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    items VARCHAR(255) NOT NULL,
    dateregistered VARCHAR(10) NOT NULL,
    solvedstatus BOOLEAN NOT NULL DEFAULT FALSE
);

-- Create the shopkeeper table (lowercase for consistency)
CREATE TABLE shopkeeper (
    id VARCHAR(20) PRIMARY KEY,
    fname VARCHAR(20),
    lname VARCHAR(20),
    dob DATE NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(255) NOT NULL
);

-- Create the customer table
CREATE TABLE customer (
    id VARCHAR(255) PRIMARY KEY,
    fname VARCHAR(255) NOT NULL,
    lname VARCHAR(255) NOT NULL,
    dob DATE NOT NULL,
    feepaid BOOLEAN NOT NULL,
    phone VARCHAR(255) NOT NULL,
    tid VARCHAR(255),
    lid VARCHAR(255),
    FOREIGN KEY (tid) REFERENCES trainer(id),
    FOREIGN KEY (lid) REFERENCES locker(locker_id)
);

-- Insert into suite (required for passenger)
INSERT INTO suite (destination, price, capacity) VALUES ('RoomA', '100', '5');

-- Insert into passenger (required for locker)
INSERT INTO passenger (id, name, address, phone, destination) VALUES ('P001', 'John Doe', '123 Main St', '1234567890', 'RoomA');

-- Insert into admin
INSERT INTO admin (fname, password) VALUES ('ALI', '123');

-- Insert into locker (now that passenger exists)
INSERT INTO locker (locker_id, location, size, assignedto) VALUES ('1', 'Gym Floor', 'Medium', 'P001');

-- Insert into manager
INSERT INTO manager (id, name, password) VALUES ('123', 'ALI', '123');

-- Insert sample data into machines (for the DELETE statement)
INSERT INTO machines (name, quantity, buydate, repairs) VALUES ('Treadmill', 5, '2023-01-01', NULL);
INSERT INTO machines (name, quantity, buydate, repairs) VALUES ('Dumbbells', 10, '2023-02-01', NULL);
INSERT INTO machines (name, quantity, buydate, repairs) VALUES ('Bench Press', 3, '2023-03-01', 'Needs repair');

-- Select from trainer and receptionist (tables are empty, but the query is valid)
SELECT * FROM trainer;
SELECT * FROM receptionist;

-- Delete from machines
DELETE FROM machines WHERE id = 3;