module sdaproject {
    requires javafx.base;
    requires javafx.graphics;
    requires javafx.fxml;
    requires javafx.controls;
    requires java.sql;
    
    // Fix these lines - assuming application anddb are your packages
    opens application;
    exports application;
    opens db;
}